# Marks Evaluator - Minimal Prototype

**What this is:** A minimal, working prototype (Flask backend + simple HTML/JS frontend) that accepts:
1. Image upload
2. Audio upload
3. Video upload
4. Typed text input (question/answer)

The backend currently uses simple, easy-to-run heuristics to return a "predicted marks" value so you can test full frontend/backend flow. It is intentionally simple so it runs without heavy ML dependencies. Instructions for improving accuracy are included in the README.

## Quick start (Linux / WSL / macOS)
1. Create a virtual environment (recommended):
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   ```
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the Flask app:
   ```bash
   python app.py
   ```
4. Open http://127.0.0.1:5000 in your browser and test.

## Files included
- `app.py` - Flask backend with `/predict` endpoint.
- `templates/index.html` - Simple frontend UI to upload inputs and request predicted marks.
- `static/js/app.js` - Frontend JavaScript handling uploads and responses.
- `requirements.txt` - Python dependencies (kept minimal).
- `README.md` - This file.

## How the heuristic predictor works (summary)
- **Text input:** marks based on word count and presence of keywords (configurable).
- **Image input:** if `pytesseract` is installed, OCR is attempted and then evaluated like text. Otherwise falls back to image file size heuristic.
- **Audio input:** if `speech_recognition` + suitable backend are installed, it attempts speech-to-text; otherwise uses file-size heuristic and returns a suggestion.
- **Video input:** attempts to extract duration using `moviepy` if installed; otherwise uses file-size heuristic.

## To make this accurate (recommended next steps)
1. Replace heuristic scoring with a trained model (BERT / multilingual transformer) or a fine-tuned regression model.
2. Use OCR (`pytesseract`) for handwritten/printed answers in images; consider models for handwriting recognition.
3. For audio, use a robust speech-to-text (OpenAI Whisper or cloud services) then score the transcript.
4. For video, extract audio & frames, transcribe audio and use frame OCR/classification as needed.
5. Collect labeled training data (answers + ground-truth marks) and train a supervised model.

## Notes
- This prototype focuses on delivering a fully-working, downloadable zip that runs locally.
- Model accuracy is intentionally not production-grade in this package — it's a plumbing + UX demo you can upgrade.
