from flask import Flask, request, render_template, jsonify
import os
from pathlib import Path

app = Flask(__name__)
UPLOAD_DIR = Path(__file__).parent / 'uploads'
UPLOAD_DIR.mkdir(exist_ok=True)

# Optional imports - used only if available
try:
    import pytesseract
    from PIL import Image
    OCR_AVAILABLE = True
except Exception as e:
    OCR_AVAILABLE = False

try:
    import speech_recognition as sr
    SR_AVAILABLE = True
except Exception:
    SR_AVAILABLE = False

try:
    from moviepy.editor import VideoFileClip
    MOVIEPY_AVAILABLE = True
except Exception:
    MOVIEPY_AVAILABLE = False

def score_text(text: str) -> float:
    """Simple heuristic to convert text -> marks (0-100)."""
    if not text or not text.strip():
        return 0.0
    words = text.split()
    wc = len(words)
    # keyword boosts (example)
    keywords = ['because','therefore','hence','in conclusion','thus','explain','define']
    bonus = sum(2 for k in keywords if k in text.lower())
    # base: cap at 100 words mapping to 80 marks, remainder gives up to 100
    base = min(wc, 100) * 0.8
    extra = max(0, wc - 100) * 0.2
    marks = base + extra + bonus
    return round(min(100, marks), 2)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    # Expect form fields: input_type in ['text','image','audio','video']
    input_type = request.form.get('input_type', 'text')
    response = {'ok': True, 'input_type': input_type, 'predicted_marks': 0, 'notes': []}

    if input_type == 'text':
        user_text = request.form.get('text', '')
        response['predicted_marks'] = score_text(user_text)
        response['notes'].append(f'Word count: {len(user_text.split())}')
        return jsonify(response)

    # For file-based inputs
    file = request.files.get('file')
    if not file:
        response['ok'] = False
        response['notes'].append('No file uploaded')
        return jsonify(response), 400
    filename = file.filename or 'uploaded.bin'
    save_path = UPLOAD_DIR / filename
    file.save(save_path)
    size_kb = save_path.stat().st_size / 1024.0
    response['notes'].append(f'File saved: {filename} ({size_kb:.1f} KB)')

    if input_type == 'image':
        if OCR_AVAILABLE:
            try:
                img = Image.open(save_path)
                text = pytesseract.image_to_string(img)
                response['notes'].append('OCR used to extract text.')
                response['predicted_marks'] = score_text(text)
                response['notes'].append(f'OCR words: {len(text.split())}')
                return jsonify(response)
            except Exception as e:
                response['notes'].append('OCR failed; falling back to size heuristic.')
        # fallback heuristic based on file size
        marks = min(100, size_kb / 10.0 + 10)  # larger image => likely more content (heuristic)
        response['predicted_marks'] = round(marks, 2)
        return jsonify(response)

    if input_type == 'audio':
        if SR_AVAILABLE:
            try:
                r = sr.Recognizer()
                with sr.AudioFile(str(save_path)) as source:
                    audio = r.record(source)
                text = r.recognize_sphinx(audio)  # uses pocketsphinx if available
                response['notes'].append('SpeechRecognition used for ASR.')
                response['predicted_marks'] = score_text(text)
                response['notes'].append(f'Transcribed words: {len(text.split())}')
                return jsonify(response)
            except Exception as e:
                response['notes'].append('ASR failed; falling back to size heuristic.')
        marks = min(100, size_kb / 5.0 + 5)
        response['predicted_marks'] = round(marks, 2)
        return jsonify(response)

    if input_type == 'video':
        if MOVIEPY_AVAILABLE:
            try:
                clip = VideoFileClip(str(save_path))
                dur = clip.duration
                # heuristic: longer video -> more likely to contain full answer
                marks = min(100, 20 + dur * 5)
                response['notes'].append(f'Video duration: {dur:.1f}s')
                response['predicted_marks'] = round(marks, 2)
                return jsonify(response)
            except Exception as e:
                response['notes'].append('Video processing failed; falling back to size heuristic.')
        marks = min(100, size_kb / 50.0 + 10)
        response['predicted_marks'] = round(marks, 2)
        return jsonify(response)

    response['ok'] = False
    response['notes'].append('Unknown input type')
    return jsonify(response), 400

if __name__ == '__main__':
    app.run(debug=True)
